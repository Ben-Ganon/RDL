import gymnasium as gym
import numpy as np
import tensorflow as tf
import random
from collections import deque
from QNet import QNet, custom_train_step
import csv
import sys
N_REPLAY_SIZE = 10000
RANDOM_REPLAY_SIZE = 1024
EPISODES = 1000
LEARNING_RATE = 0.0005
LAYER_NUM = 3
LAYER_SIZE = 16
# # Layer size array where first layer size is LAYER_SIZE and each subsequent layer size is current_layer_size/2
# LAYER_SIZE_ARRAY = [LAYER_SIZE // (2 ** i) for i in range(LAYER_NUM)]
LAYER_SIZE_ARRAY = [32, 32, 32]
# LAYER_SIZE_ARRAY = [LAYER_SIZE for i in range(LAYER_NUM)]
GREEDY_EPSILON = 1.0
GREEDY_EPSILON_DECAY = 0.9
MIN_GREEDY_EPSILON = 0.01
MAX_ITERATION = 3000
DISCOUNT = 0.95
BATCH_SIZE = 8
RANDOM_BATCH_SIZE = 8
UPDATE_TARGET_EVERY = 8
REWARD_ITER = 100
OPTIMIZER = "adam"
DO_RENDER = False
LOAD = False
RENDER_METHOD = "human" if DO_RENDER else None
VALUE_CHECKPT = "Ex_1/checkpoints/Qnet_values_checkpoint_final"
TARGET_CHECKPT = "Ex_1/checkpoints/Qnet_target_checkpoint_final"

train_summary_writer = tf.summary.create_file_writer("Ex_1/section_2_logs")
tf.random.set_seed(0)


def initialize_experience_replay():
    que = deque(maxlen=N_REPLAY_SIZE)
    return que


def sample_batch(que, batch_size):
    if len(que) < batch_size:
        return random.sample(que, len(que))
    return random.sample(que, batch_size)


def train_agent():
    env = gym.make('CartPole-v1', render_mode=RENDER_METHOD)
    observation = env.observation_space
    action = env.action_space
    replay_q = initialize_experience_replay()
    random_replay_q = initialize_experience_replay()
    greedy_epsilon = GREEDY_EPSILON
    Qnet_target = QNet(layer_sizes=LAYER_SIZE_ARRAY, output_size=action.n, optimizer=OPTIMIZER, learning_rate=LEARNING_RATE)
    Qnet_values = QNet(layer_sizes=LAYER_SIZE_ARRAY, output_size=action.n, optimizer=OPTIMIZER, learning_rate=LEARNING_RATE)
    if LOAD:
        dummy_outputs = Qnet_target.call(np.zeros((1, 4)))
        dummy_outputs = Qnet_values.call(np.zeros((1, 4)))
        Qnet_target.load_weights(TARGET_CHECKPT)
        Qnet_values.load_weights(VALUE_CHECKPT)

    print(f"paramters: {LAYER_SIZE_ARRAY}\noptimizer: {OPTIMIZER}\nlearning rate: {LEARNING_RATE}\n"
          f"greedy epsilon: {GREEDY_EPSILON}\ngreedy epsilon decay: {GREEDY_EPSILON_DECAY}\n"
          f"max iterations: {MAX_ITERATION}\ndiscount: {DISCOUNT}\nbatch size: {BATCH_SIZE}\n"
          f"update target every: {UPDATE_TARGET_EVERY}\nreward iteration: {REWARD_ITER}\n"
          f"Replay size: {N_REPLAY_SIZE}\n")
    avg_rewards = []
    not_updated_count = 0
    for episode_num in range(EPISODES):
        state = env.reset()[0]
        # state = np.reshape(state, (1, 4))
        state = tf.constant(np.reshape(state, (1, 4)))
        done = False
        if DO_RENDER:
            env.render()
        avg_loss = 0
        if episode_num % REWARD_ITER == REWARD_ITER - 1:
            # avg_reward /= REWARD_ITER
            # print("Average reward for last {} episodes: {}".format(REWARD_ITER, avg_reward))
            # avg_reward = 0
            Qnet_target.save_weights(TARGET_CHECKPT)
            Qnet_values.save_weights(VALUE_CHECKPT)
        iter_reward = 0
        for iteration in range(MAX_ITERATION):
            rand = np.random.random()
            if rand < greedy_epsilon:
                action = np.random.choice([0, 1])
            else:
                action = np.argmax(Qnet_target.call(state))
            next_state, reward, done, truncated, _ = env.step(action)

            iter_reward += reward
            # next_state = np.reshape(next_state, (1, 4))
            next_state = tf.constant(np.reshape(next_state, (1, 4)))
            if len(random_replay_q) < RANDOM_REPLAY_SIZE:
                random_replay_q.append((state, action, reward, next_state, done))
            replay_q.append((state, action, reward, next_state, done))
            replays = sample_batch(replay_q, BATCH_SIZE)
            random_replays = sample_batch(random_replay_q, RANDOM_BATCH_SIZE)
            replays += random_replays
            replay_length = len(replays)
            y_i_array = []
            state_array = []
            action_array = []
            # add the replay values to the array in the most efficient way without for loops
            for replay in replays:
                if replay[4]:
                    y_i_array.append(replay[2])
                else:
                    y_i_array.append(replay[2] + DISCOUNT * np.max(Qnet_target.call(replay[3])))
                state_array.append(replay[0])
                action_array.append(replay[1])
            y_i_array = tf.constant(y_i_array, shape=(replay_length, 1))
            # state_array = tf.constant(state_array, shape=(replay_length, 4))
            state_array = tf.concat(state_array, axis=0)
            action_array = tf.constant(action_array, shape=(replay_length, 1))
            loss = custom_train_step(Qnet_values, state_array, y_i_array, action_array)
            avg_loss += loss
            if not_updated_count % UPDATE_TARGET_EVERY == UPDATE_TARGET_EVERY -1:
                # copy model parameters from Qnet_values to Qnet_target
                Qnet_target.set_weights(Qnet_values.get_weights())
                not_updated_count = 0

            state = next_state
            iterations_done = iteration
            not_updated_count += 1
            if done or truncated:
                break
        greedy_epsilon = max(MIN_GREEDY_EPSILON, greedy_epsilon * GREEDY_EPSILON_DECAY)
        avg_rewards.append(iter_reward)
        with train_summary_writer.as_default():
            tf.summary.scalar('avg_loss', avg_loss / iterations_done, step=episode_num)
        with train_summary_writer.as_default():
            tf.summary.scalar('rewards_per_episode', iter_reward, step=episode_num)

        if len(avg_rewards) > 100:
            avg_rewards.pop(0)
        print(f"Episode: {episode_num}, Loss: {(avg_loss / (iterations_done)):4.6f}., Epsilon: {greedy_epsilon:1.3f}, "
              f"Reward: {iter_reward}, Que Size: {len(replay_q)}, Average Reward: {sum(avg_rewards) / len(avg_rewards):3.0f}")
    Qnet_target.save_weights(TARGET_CHECKPT)
    Qnet_values.save_weights(VALUE_CHECKPT)
    env.close()

def test_agent():
    env = gym.make('CartPole-v1', render_mode=RENDER_METHOD)
    observation = env.observation_space
    action = env.action_space
    replay_q = initialize_experience_replay()
    greedy_epsilon = GREEDY_EPSILON
    Qnet_target = QNet(layer_sizes=LAYER_SIZE_ARRAY, output_size=action.n, optimizer=OPTIMIZER,
                       learning_rate=LEARNING_RATE)
    Qnet_values = QNet(layer_sizes=LAYER_SIZE_ARRAY, output_size=action.n, optimizer=OPTIMIZER,
                       learning_rate=LEARNING_RATE)
    dummy_outputs = Qnet_target.call(np.zeros((1, 4)))
    dummy_outputs = Qnet_values.call(np.zeros((1, 4)))
    Qnet_target.load_weights(TARGET_CHECKPT)
    Qnet_values.load_weights(VALUE_CHECKPT)
    avg_reward = 0
    for episode_num in range(EPISODES):
        episode_reward = 0
        state = env.reset()[0]
        state = tf.constant(np.reshape(state, (1, 4)))
        if DO_RENDER:
            env.render()
        if episode_num % REWARD_ITER == REWARD_ITER - 1:
            avg_reward /= REWARD_ITER
            print("Average reward for last {} episodes: {}".format(REWARD_ITER, avg_reward))
            avg_reward = 0
        for iteration in range(MAX_ITERATION):
            action = np.argmax(Qnet_target.call(state))
            next_state, reward, done, truncated, _ = env.step(action)
            iterations_done = iteration
            if done or truncated:
                break
            avg_reward += reward
            episode_reward += reward
            next_state = tf.constant(np.reshape(next_state, (1, 4)))
            state = next_state
        print(f'Episode: {episode_num}, Reward: {episode_reward}, Iterations: {iterations_done}')

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "train":
            train_agent()
        elif sys.argv[1] == "test":
            test_agent()
        else:
            raise ValueError("Invalid argument. Please use either 'train' or 'test' as the argument.")
